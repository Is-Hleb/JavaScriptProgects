class ComplexNumber{
    constructor(substance, complex) {
        this.sub = substance;
        this.complex = complex;
    }
    static sum(one, two) {
        return new ComplexNumber(one.sub + two.sub, one.complex + two.complex);
    }
    static mul(one, two) {
        return new ComplexNumber(one.sub * two.sub - one.complex * two.complex, one.sub * two.complex + one.complex * two.sub);
    }
    static sqr(one) {
        return new ComplexNumber(one.sub ** 2 - one.complex ** 2, 2 * one.sub * one.complex);
    }
    static abs(one) {
        return Math.sqrt(one.sub ** 2 + one.complex ** 2);
    }
    mulOnNum(num) {
        this.sub *= num;
        this.complex *= num;
    }
}
