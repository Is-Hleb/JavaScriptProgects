const h = window.innerHeight;
const w = window.innerWidth;
const canvas = document.getElementById('Mal');
const ctx = canvas.getContext('2d');
const dis = w/h;
const maxIt = 200;

canvas.width = w;
canvas.height = h;

let kx = 4;
let ky = 4;
let k = 1;

let z = new ComplexNumber(0, 0);
let c = new ComplexNumber(-1, 0);

function draw() {
    const imageData = ctx.createImageData(w, h);
    let data = imageData.data;

    for (let i = 0; i < w; i++) {
        for (let j = 0; j < h; j++) {
            let ind = (i + j * w) * 4;
            let x = (i - w/2) / (w / kx) / k; 
            let y = (j - h/2) / (h / ky) / k;
            //console.log(x);

            let it = 0;
            c.sub = x ;
            c.complex = y;
            z = new ComplexNumber(0, 0);

            do {
                z = ComplexNumber.sqr(z);
                z = ComplexNumber.sum(c, z);
                it ++;
                if(ComplexNumber.abs(z) > 2)
                    break;
                
            } while (it < maxIt);

            let col = [];
            if(it < maxIt) {
                col = [it * 25, it * 10, it * 7];
            } else {
                col = [255, 150, 0];
            }
            

            data[ind] = col[0];//R
            data[ind + 1] = col[1];//G
            data[ind + 2] = col[2];//B
            data[ind + 3] = 255;//opacity
        }
    }
    ctx.putImageData(imageData, 0, 0);
}

draw();

